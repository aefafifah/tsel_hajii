<div class="card shadow-sm p-4 rounded {{ $attributes->get('class') }}">
    {{ $slot }}
</div>
